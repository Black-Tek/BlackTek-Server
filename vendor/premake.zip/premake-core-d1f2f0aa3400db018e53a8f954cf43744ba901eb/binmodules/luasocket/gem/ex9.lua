for chunk in source.file(io.stdin) do
  io.write(chunk)
end
